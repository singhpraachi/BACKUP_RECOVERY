# Backup & Recovery Package

This package contains scripts and documentation to perform full and incremental backups, encryption, optional S3 sync, verification, and restores for MySQL and PostgreSQL.

## Quick start
1. Edit config.sh with your environment variables.
2. Make scripts executable: chmod +x *.sh
3. Run a manual backup for each DB type:
   ./mysql_full_backup.sh
   ./pg_full_backup.sh
4. Verify with: ./verify_rowcounts.sh
5. Automate with cron after testing.
